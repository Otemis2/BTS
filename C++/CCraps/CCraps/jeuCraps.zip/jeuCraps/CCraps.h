/*# -----------------------------------------------------------------------
# Nom Fichier: CCraps.h
# Sujet : D�claration de la classe CCraps.
# Version : 0.1
# Auteur : Chameroy Estelle
# Cr�ation : 13/11/2018
# Mise � jour :
# --------------------------------------------------------------------------*/
#ifndef CCRAPS_H
#define CCRAPS_H
class CCraps
{
public:
    CCraps();
    ~CCraps();
    unsigned short lancerDe();
};

#endif // CCRAPS_H
