/*# -----------------------------------------------------------------------
# Nom Fichier: CCraps.cpp
# Sujet : Definition de la classe CCraps.
# Version : 0.1
# Auteur : Chameroy Estelle
# Cr�ation : 13/11/2018
# Mise � jour :
# --------------------------------------------------------------------------*/
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include "CCraps.h"
using namespace std;
/*# -----------------------------------------------------------------------
# Nom Fonction Membre :CCraps
# Classe : CCraps
# Sujet :constructeur de la classe
# Version : 0.1
# Entree : aucune
# Sortie : aucune
# Retour : aucun
# Auteur : Chameroy Estelle
# Cr�ation : 13/11/2018
# Mise � jour :
# -----------------------------------------------------------------------*/
CCraps::CCraps()
{
    srand(time(NULL));
    //initialise la fonction rand
}
/*# -----------------------------------------------------------------------
# Nom Fonction Membre :~CCraps
# Classe : CCraps
# Sujet :destructeur de la classe
# Version : 0.1
# Entree : aucune
# Sortie : aucune
# Retour : aucun
# Auteur : Chameroy Estelle
# Cr�ation : 13/11/2018
# Mise � jour :
# -----------------------------------------------------------------------*/
CCraps::~CCraps()
{

}
/*# -----------------------------------------------------------------------
# Nom Fonction Membre :lancerDe
# Classe : CCraps
# Sujet :permet de lancer les deux d�s
# Version : 0.1
# Entree : aucune
# Sortie : aucune
# Retour : somme des deux d�s : unsigned short
# Auteur : Chameroy Estelle
# Cr�ation : 13/11/2018
# Mise � jour :
# -----------------------------------------------------------------------*/
unsigned short CCraps::lancerDe()
{
    unsigned short de1;
    unsigned short de2;

    de1 = rand()%6 +1;
    de2 = rand()%6 +1;
    return de1+de2;

}
